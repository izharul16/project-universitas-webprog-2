<?php

class Dashboard extends CI_Controller{

    public function index()
    {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function mahasiswa()
    {
        $this->load->model('model_mhs');
        $data['universitas'] = $this->model_mhs->mhs();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebarm');
        $this->load->view('admin/data_mahasiswa',$data);
        $this->load->view('templates/footer');
    }
    public function dosen()
    {
        $this->load->model('model_mhs');
        $data['universitas'] = $this->model_mhs->dosen();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebard');
        $this->load->view('admin/dosen',$data);
        $this->load->view('templates/footer');
    }
    public function matkul()
    {
        $this->load->model('model_mhs');
        $data['universitas'] = $this->model_mhs->matkul();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebarj');
        $this->load->view('admin/matkul',$data);
        $this->load->view('templates/footer');
    }
}

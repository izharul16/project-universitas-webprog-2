<!DOCTYPE html>
<html lang="en">

<head>
    <title>Daftar Mahasiswa</title>
</head>

<body>
    <div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Mahasiswa</h1>
        </div>
        <center>
            <table id="example1" class="table table-bordered table-striped">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Nim</th>
                </tr>

                <?php foreach ($universitas as $uni) : ?>
                    <div class="row">
                        <tr>
                            <td><?php echo $uni['no']; ?></td>
                            <td><?php echo $uni['nama_mahasiswa']; ?></td>
                            <td><?php echo $uni['nim']; ?></td>
                        </tr>

                    <?php endforeach; ?>
            </table>
        </center>
    </div>
    </div>
</body>

</html>
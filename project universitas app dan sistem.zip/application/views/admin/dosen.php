<!DOCTYPE html>
<html lang="en">

<head>
    <title>Dosen</title>
</head>

<body>
<div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Dosen</h1>
        </div>
    <center>
        <table id="example1" class="table table-bordered table-striped">
            <tr>
                <th>No</th>
                <th>Nama Dosen</th>
                <th>Kode Dosen</th>
            </tr>

            <?php foreach ($universitas as $uni) : ?>
                <div class="row">
                    <tr>
                        <td><?php echo $uni['no']; ?></td>
                        <td><?php echo $uni['nama_dosen']; ?></td>
                        <td><?php echo $uni['kode_dosen']; ?></td>
                    </tr>

                <?php endforeach; ?>
    </center>
    </table>
    </div>
    </div>
</body>

</html>
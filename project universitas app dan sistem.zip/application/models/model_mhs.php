<?php

class Model_mhs extends CI_model{
    public function mhs()
    {
        return $this->db->get('tb_mahasiswa')->result_array();
        ;
    }

    public function matkul()
{
        return $this->db->get('tb_matakuliah')->result_array();
        ;
}
    public function dosen()
{
        return $this->db->get('tb_dosen')->result_array();
        ;
}
}